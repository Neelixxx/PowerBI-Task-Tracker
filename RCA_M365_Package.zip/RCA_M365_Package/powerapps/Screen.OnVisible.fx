Set(varTeam, Blank()); Set(varTask, Blank()); Clear(colChecks); Refresh(RCA_Tracker)
