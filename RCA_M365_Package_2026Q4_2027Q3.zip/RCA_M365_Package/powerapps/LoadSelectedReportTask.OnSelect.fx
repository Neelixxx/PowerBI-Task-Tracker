If(
    CountRows(PowerBIIntegration.Data) = 1,
    Set(varTask, LookUp(RCA_Tracker_2026Q4_2027Q3, TaskKey = First(PowerBIIntegration.Data).TaskKey));
    ClearCollect(colChecks, Filter(RCA_Tracker_2026Q4_2027Q3, ParentKey = varTask.TaskKey));
    Reset(txtAssigned); Reset(txtComments); Reset(dpStart); Reset(dpDue); Reset(dpCompleted); Reset(chkCompleted),
    Set(varTask, Blank()); Clear(colChecks)
)
