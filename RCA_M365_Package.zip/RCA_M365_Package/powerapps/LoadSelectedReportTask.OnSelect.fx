If(
    CountRows(PowerBIIntegration.Data) = 1,
    Set(varTask, LookUp(RCA_Tracker, TaskKey = First(PowerBIIntegration.Data).TaskKey));
    ClearCollect(colChecks, Filter(RCA_Tracker, ParentKey = varTask.TaskKey));
    Reset(txtAssigned); Reset(txtComments); Reset(dpStart); Reset(dpDue); Reset(dpCompleted); Reset(chkDone),
    Set(varTask, Blank()); Clear(colChecks)
)
