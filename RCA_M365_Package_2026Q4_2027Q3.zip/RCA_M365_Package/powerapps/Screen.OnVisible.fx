Set(varTeam, Blank()); Set(varTask, Blank()); Clear(colChecks); Refresh(RCA_Tracker_2026Q4_2027Q3)
