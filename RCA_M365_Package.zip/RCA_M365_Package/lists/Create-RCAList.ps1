# Requires PowerShell 7 and PnP.PowerShell installed through your approved work process.
[CmdletBinding()]
param([Parameter(Mandatory)][string]$SiteUrl,[Parameter(Mandatory)][string]$ClientId,[string]$ListName='RCA_Tracker')
$ErrorActionPreference='Stop'
Import-Module PnP.PowerShell -ErrorAction Stop
Connect-PnPOnline -Url $SiteUrl -Interactive -ClientId $ClientId
$rows=Get-Content (Join-Path $PSScriptRoot '../data/RCA_Records.json') -Raw | ConvertFrom-Json
$fields=Get-Content (Join-Path $PSScriptRoot 'columns.json') -Raw | ConvertFrom-Json
$list=Get-PnPList -Identity $ListName -ErrorAction SilentlyContinue
if(-not $list){$list=New-PnPList -Title $ListName -Template GenericList -OnQuickLaunch}
Set-PnPList -Identity $ListName -EnableVersioning $true | Out-Null
foreach($f in $fields){
 $existing=Get-PnPField -List $ListName -Identity $f.name -ErrorAction SilentlyContinue
 if(-not $existing){Add-PnPField -List $ListName -InternalName $f.name -DisplayName $f.name -Type $f.type | Out-Null}
 elseif($existing.TypeAsString -ne $f.type){throw "Existing field $($f.name) has incompatible type $($existing.TypeAsString). Use a new list; no data was replaced."}
 if($f.indexed){Set-PnPField -List $ListName -Identity $f.name -Values @{Indexed=$true} | Out-Null}
 if($f.unique){Set-PnPField -List $ListName -Identity $f.name -Values @{EnforceUniqueValues=$true;Required=$true} | Out-Null}
 if($f.type -eq 'DateTime'){Set-PnPField -List $ListName -Identity $f.name -Values @{DisplayFormat=0} | Out-Null}
}
$existingKeys=@{}
Get-PnPListItem -List $ListName -PageSize 500 -Fields 'TaskKey' | ForEach-Object {if($_['TaskKey']){$existingKeys[$_['TaskKey']]=$true}}
$added=0;$skipped=0
foreach($r in $rows){
 if($existingKeys.ContainsKey($r.TaskKey)){$skipped++;continue}
 $v=@{}
 foreach($p in $r.PSObject.Properties){
  if($null -eq $p.Value -or $p.Value -eq ''){continue}
  if($p.Name -in @('StartDate','DueDate','CompletedDate','CycleStart','CycleEnd')){$v[$p.Name]=[datetime]::ParseExact($p.Value,'yyyy-MM-dd',[cultureinfo]::InvariantCulture)}
  else{$v[$p.Name]=$p.Value}
 }
 Add-PnPListItem -List $ListName -Values $v | Out-Null
 $existingKeys[$r.TaskKey]=$true;$added++
}
$viewFields=@('TaskCode','TrackingYear','Cycle','Phase','BusinessGroup','Team','TaskText','AssignedTo','Done','StartDate','DueDate','CompletedDate','Comments')
$parent="<Eq><FieldRef Name='RowKind'/><Value Type='Text'>Task</Value></Eq>"
$views=@{'All Tasks'=$parent;'Data & Reporting'="<And>$parent<Eq><FieldRef Name='Team'/><Value Type='Text'>Data &amp; Reporting</Value></Eq></And>";'Research & Analysis'="<And>$parent<Eq><FieldRef Name='Team'/><Value Type='Text'>Research &amp; Analysis</Value></Eq></And>";'Design & Insights'="<And>$parent<Eq><FieldRef Name='Team'/><Value Type='Text'>Design &amp; Insights</Value></Eq></And>"}
foreach($name in $views.Keys){
 if(-not(Get-PnPView -List $ListName -Identity $name -ErrorAction SilentlyContinue)){
  Add-PnPView -List $ListName -Title $name -Fields $viewFields -Query "<Where>$($views[$name])</Where><OrderBy><FieldRef Name='SortOrder'/></OrderBy>" -RowLimit 100 -Paged -SetAsDefault:($name -eq 'All Tasks') | Out-Null
 }
}
$list=Get-PnPList -Identity $ListName
Write-Host "Added $added records; skipped $skipped existing records. Existing task updates were preserved."
Write-Host "Site URL: $SiteUrl"
Write-Host "List GUID for Power BI parameter: $($list.Id)"
