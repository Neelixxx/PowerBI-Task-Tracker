# RCA Quarterly Task Tracker — Microsoft 365 Package

Reporting window: **Quarter 4 2026 through Quarter 3 2027**.

This complete package contains the updated task data, Microsoft Lists provisioning files, Power Apps control source, and a Power BI Desktop project. Connections and publishing must be completed in your work environment. Power BI Desktop and Power Apps Studio were not available here for native application testing. The Power Apps file is pasteable screen/control source, not a finished `.msapp`.

## Open the Power BI file first

1. Copy the ZIP to your work computer and choose **Extract All**. Keep the extracted folder structure together.
2. Open **`powerbi/RCA.pbip`** in Power BI Desktop. Do not upload the `.pbip` file alone or separate it from `RCA.Report` and `RCA.SemanticModel`.
3. Select **Refresh** to load the included offline task snapshot. The default parameter `UseSharePoint=false` needs no work connection. Import `powerbi/RCA_Theme.json` through **View > Themes > Browse for themes**.
4. Review Overview and the three team pages. The overview starts with all values selected. Year and Quarter slicers let you choose 2026 Quarter 4 or 2027 Quarters 1–3, alongside Phase, Business Group and Team.
5. If your work process requires a `.pbix`, open this project and use **File > Save As > Power BI file (.pbix)** in Desktop. A `.pbix` has not been fabricated or included; the supplied native format is `.pbip`. If your Desktop requires it, enable the Power BI project and PBIR options, then restart Desktop.

## What changed

- `Title` and `TaskCode`: `Team.BusinessGroup.Phase.Task`, with two-digit phase and task numbers, for example `DI.AU.01.01`.
- `TaskKey`: the code followed by year and quarter, for example `DI.AU.01.01.2026.Q4`.
- Checklist example: `DR.AU.01.03.C01.2026.Q4`; its `ParentKey` is `DR.AU.01.03.2026.Q4`.
- Period terminology is Quarter throughout the data, queries, model, filters, app and setup files.
- Fields are `Quarter`, `QuarterNumber`, `QuarterStart` and **`QuarterEnd`** (correct spelling).
- The completion checkbox field is **`Completed`**, a Yes/No value. `CompletedDate` remains the date field.
- Research & Analysis Phase 1 now has eight tasks. **Assign topic researchers** is Task 8; the removed topic-socialization task is absent from every business group and quarter.
- Planned due dates for the shifted quarters retain their original day offsets from quarter start, including preparation due in December 2026 for Quarter 1 2027. Blank actual start/completion dates remain blank.

| TrackingYear | Quarter | QuarterStart | QuarterEnd | Parent tasks | Checklist items |
|---|---|---|---|---:|---:|
| 2026 | Quarter 4 | 2026-10-01 | 2026-12-31 | 385 | 91 |
| 2027 | Quarter 1 | 2027-01-01 | 2027-03-31 | 385 | 91 |
| 2027 | Quarter 2 | 2027-04-01 | 2027-06-30 | 385 | 91 |
| 2027 | Quarter 3 | 2027-07-01 | 2027-09-30 | 385 | 91 |

Total: **1,904 rows = 1,540 parent tasks + 364 checklist items**. Data & Reporting Phase 1 Task 3 retains 13 checklist items in each business group and quarter. Checklist items are stored in the same list and shown inside the parent task editor, with no separate checklist tab. They do not add to dashboard task totals.

## Contents

| File or folder | Purpose |
|---|---|
| `data/RCA_Records.csv` | Revised records for inspection or import |
| `data/RCA_Records.json` | Same revised records used by the list script |
| `lists/columns.json` | Exact field names, types, indexing and uniqueness |
| `lists/Create-RCAList.ps1` | Create a list, import records and create team views |
| `powerapps/RCA_Controls.yaml` | Pasteable task tracker controls and inline checklist editor |
| `powerapps/Screen.OnVisible.fx` | Screen initialization formula |
| `powerapps/LoadSelectedReportTask.OnSelect.fx` | Optional embedded report selection button formula |
| `powerbi/RCA.pbip` with adjacent folders | Four-page report and semantic model |
| `powerbi/RCA_Query.m` | Inspectable Power Query source with embedded snapshot |
| `powerbi/RCA_Theme.json` | Report color theme |
| `validation.json` | Automated checks and native-testing limitations |

## Create the Microsoft List

This version targets a **new list named `RCA_Tracker_2026Q4_2027Q3`**. Use it instead of appending these revised records to your earlier list: identifiers and field names have changed. The package does not update an existing deployed list or recover progress entered there after the original export. Retain any such progress separately before replacing an existing operational tracker.

Use PowerShell 7 and an organization-approved PnP.PowerShell installation and Entra client ID. A site owner or authorized colleague can run:

```powershell
./lists/Create-RCAList.ps1 -SiteUrl 'https://YOURTENANT.sharepoint.com/sites/YOURSITE' -ClientId 'YOUR_APPROVED_ENTRA_APPLICATION_CLIENT_ID'
```

Keep the default list name so the supplied app formulas match. Save the list GUID printed by the script for Power BI. The script creates fields with the correct internal names, enables version history, enforces unique TaskKeys and creates All Tasks and three team views. It imports missing rows and preserves previously imported progress on reruns. It refuses to seed a list containing keys outside this package.

`AssignedTo`, `Team`, `BusinessGroup`, `Quarter`, `Phase` and `RowKind` are text fields in this package; `Completed` is Boolean/Yes-No and date fields use Date only display. If you choose to change fields to Person or Choice in a manually created list, the supplied Power Apps formulas and Power Query must be adapted to those record-valued types. Merely changing a display name does not change an existing internal field name. The provisioning script is the supported route for creating this package's exact schema; `columns.json` is the reference for manual setup.

Standard list task views hide child rows. Use the app for the inline checklist and completion guard. A parent is counted complete only when its `Completed` flag is true and all required checklist items are complete. Direct list edits do not enforce the app guard, but the report still applies that counting rule.

## Connect Power BI to the list

In Desktop choose **Transform data > Edit parameters**:

- `UseSharePoint`: true
- `SiteUrl`: the SharePoint site URL
- `ListId`: the GUID from the script, without braces

Sign in with your organizational account and refresh. Required fields are checked by the query; a mismatched list produces an explicit schema error. If the connector exposes different display names, map them to `lists/columns.json` before the required-field check.

Verify 1,904 imported records and 1,540 parent tasks, then publish to an authorized workspace. Configure organizational credentials and scheduled refresh. The model uses import mode: app updates save to the list immediately, while Power BI totals update after semantic-model refresh. The offline embedded snapshot is independent of the CSV; edit the connected list for normal ongoing operation.

## Set up the Power Apps editor

1. Create a blank canvas app with a tablet/custom **1366 × 900** layout.
2. Add your SharePoint list as a data source named `RCA_Tracker_2026Q4_2027Q3`.
3. Copy all of `powerapps/RCA_Controls.yaml`, then paste it into the blank screen using Power Apps Studio's control-code paste feature. This is control source, not an app-import ZIP. Resolve any control-version/property differences reported by Studio.
4. Set the screen's **OnVisible** to `powerapps/Screen.OnVisible.fx`.
5. Play the app. Year offers All, 2026 and 2027. Quarter offers All and Quarters 1–4. Team tabs and Phase/Business Group filters narrow the task list. Empty year/quarter combinations correctly show no tasks.
6. Select a task, change its fields, check **Task completed**, and choose **Save task**. Checklist changes save immediately. Complete every checklist item before saving its parent as complete; unchecking a child reopens its parent.
7. Resolve App Checker errors and any SharePoint delegation warnings. Parent browsing uses delegated Filter/SortByColumns; only the selected parent's small checklist is loaded locally. Do not load the entire list into a limited local collection.
8. Save, publish and share the app with your team. Grant list access separately. Refresh before editing a task someone else may be updating; this starter uses last-saved field updates rather than a custom conflict-resolution workflow.

## Add the editor to Power BI and SharePoint

After publishing the report, open it in the Power BI service, add a Power Apps visual and pass **TaskKey**. Create a new app from the visual, or configure an existing app so the PowerBIIntegration object is present. Add the list connection and the supplied controls as above.

Add a button labeled **Load selected report task** with the formula from `powerapps/LoadSelectedReportTask.OnSelect.fx` as its OnSelect. Select exactly one parent task in the report table, then use the button to load it. Configure the task table to filter the Power Apps visual. Passing only the selected key avoids the visual's 1,000-record transfer limit; checklist rows load from the list itself. Save and publish the embedded app, share it separately, and save the report. App/report IDs and this final binding must be assigned at work.

Use the SharePoint Power BI web part for the published report and optionally the Power Apps web part for the standalone editor. Sharing a SharePoint page does not grant the underlying list, app or report permissions. App filters and report slicers operate independently; the selection button is the explicit bridge from the report to the task editor.

## Acceptance checks at work

- Open and refresh the project; ensure Overview starts with All selected and the three team pages restrict their respective teams.
- Filter 2027 / Quarter 2 / Design & Insights / FCM and verify the selection. Reset filters to All.
- Confirm `RA.AU.01.08.2026.Q4` is **Assign topic researchers**, and Research & Analysis Phase 1 has no Task 9.
- Complete a regular task, reload the app and refresh the Power BI model: completed increases by one and remaining decreases by one.
- For a Task 3 parent, leave one check open and verify parent completion is rejected. Finish all 13, save the parent and refresh: it counts as one completed task. Uncheck a child and confirm the parent reopens.
- Check the four quarter date ranges, dates before quarter start, numeric sorting and saved comments.
- Rerun the provisioning script and verify no duplicate keys or lost progress.

## Microsoft references

- Power BI project format: https://learn.microsoft.com/power-bi/developer/projects/projects-overview
- Semantic model format: https://learn.microsoft.com/power-bi/developer/projects/projects-dataset
- Control-code paste: https://learn.microsoft.com/power-apps/maker/canvas-apps/code-view
- Power Apps visual: https://learn.microsoft.com/power-apps/maker/canvas-apps/powerapps-custom-visual
- SharePoint delegation: https://learn.microsoft.com/power-apps/maker/canvas-apps/connections/connection-sharepoint-online
- PnP authentication: https://pnp.github.io/powershell/cmdlets/Connect-PnPOnline.html
